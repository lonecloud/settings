/**
 * ${DESC}
 * @author ${USER}
 * @version v1.0
 * @date ${DATE} ${HOUR}:${MINUTE}
 */
module #[[$MODULE_NAME$]]# {
}