#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
/**
 * ${DESC}
 * @author ${USER}
 * @version v1.0
 * @date ${DATE} ${HOUR}:${MINUTE}
 */
public @interface ${NAME} {
}
